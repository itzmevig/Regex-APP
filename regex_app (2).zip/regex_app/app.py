from flask import Flask, render_template, request
import re

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/results', methods=['POST'])
def results():
    test_string = request.form['test_string']
    regex = request.form['regex']
    matches = re.findall(regex, test_string)
    return render_template('index.html', matches=matches, test_string=test_string, regex=regex)

# Email Validation Route: Accepts both GET and POST methods
@app.route('/validate-email', methods=['GET', 'POST'])
def validate_email():
    if request.method == 'POST':
        email = request.form['email']
        email_pattern = r'^[\w\.-]+@[\w\.-]+\.\w{2,}$'
        is_valid = re.match(email_pattern, email) is not None
        return render_template('email_validation.html', is_valid=is_valid, email=email)
    return render_template('email_validation.html')  # Renders the form on GET request
 # For GET request, just render the form

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
